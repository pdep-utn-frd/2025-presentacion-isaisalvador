# **PRESENTACIÓN**
*Soy Isai Salvador, tengo 21 años, soy de los cardales y actualmente estoy cursando segundo año.* 
___
# **PASATIEMPOS/INTERESES**
*Me gusta jugar y mirar futbol, escuchar música, ver peliculas/series (en especial las de ciencia ficción) y disfruto sacarle fotos a mi gata.*
___
# **ELECCIÓN DE LA CARRERA**
*siendo sincero, elegí la carrera no principalmente por la programación, sino por los diversos espacios laborales en el que uno como ingeniero en sistemas se puede desempeñar y también por su rica demanda de trabajo.*

